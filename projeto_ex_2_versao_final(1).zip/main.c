/*
// Projeto SO - exercicio 1, version 03
// Sistemas Operativos, DEI/IST/ULisboa 2017-18
//-----------------------Grupo 66-------------------------------------
//----------------Ricardo Velhinho 86505------------------------------
//----------------Manuel Valverde  86468------------------------------
*/

/*--------------------------------------------------------------------
| Includes
---------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include "matrix2d.h"
#include "mplib3.h"

/*--------------------------------------------------------------------
| Defines
---------------------------------------------------------------------*/

typedef struct{
  	int n_linhas;
  	int N;
  	int id;
  	int iter;
  	int trab;
} args;

/*--------------------------------------------------------------------
| Function: simul
| Description: Calcula cada fatia de cada tarefa e envia para a thread 0
---------------------------------------------------------------------*/

void *simul(void *a) {
	args *estrutura = (args *) a;
  int iter, i, j, myid = estrutura->id+1;
  double value;
	double buff[estrutura->N+2],buff2[estrutura->N+2];
  double *buffer,*buffer2,*mensagem_a_enviar,*mensagem_a_enviar2;
  int t[4];
  buffer=buff;
  buffer2=buff2;

	DoubleMatrix2D *m,*aux, *tmp;

	if(estrutura->N+2<2 || estrutura->n_linhas+2<2)
	 return NULL;

  receberMensagem(0,myid,t,sizeof(t));

  m = dm2dNew(estrutura->n_linhas+2,estrutura->N+2);
  aux = dm2dNew(estrutura->n_linhas+2,estrutura->N+2);

  /* De acordo com o myid, vao ser inicializadas as matrizes correspondentes a cada fatia com as temperaturas especificas */
  for(i=0; i<estrutura->n_linhas+2; i++)
    dm2dSetLineTo(m, i, 0);

  if( myid==1 ){
    dm2dSetLineTo (m, 0, t[0]);
    dm2dSetColumnTo (m, 0, t[2]);
    dm2dSetColumnTo (m, estrutura->N+1,t[3]);
  }

  if( myid == estrutura->trab ){
    dm2dSetLineTo (m, estrutura->n_linhas+1, t[1]);
    dm2dSetColumnTo (m, 0, t[2]);
    dm2dSetColumnTo (m, estrutura->N+1,t[3]);
  }

  else if( myid>1 && myid<estrutura->trab){
    dm2dSetColumnTo (m, 0, t[2]);
    dm2dSetColumnTo (m, estrutura->N+1,t[3]);
  }

  dm2dCopy (aux,m);

  for (iter = 0; iter < estrutura->iter; iter++) {
 	 
    for (i = 1; i < estrutura->n_linhas + 1; i++)
      for (j = 1; j < estrutura->N + 1; j++) {
        value = ( dm2dGetEntry(m, i-1, j) + dm2dGetEntry(m, i+1, j) +
		    dm2dGetEntry(m, i, j-1) + dm2dGetEntry(m, i, j+1) ) / 4.0;
        dm2dSetEntry(aux, i, j, value);
      }

    tmp = aux;
    aux = m;
    m = tmp;
   
    /* Antes de acabar cada iteracao vao ser trocadas informacoes entre fatias adjacentes */

    if(myid>=1 && myid<estrutura->trab && estrutura->trab>1){
	    mensagem_a_enviar=dm2dGetLine(m,estrutura->n_linhas);
	   	enviarMensagem(myid, myid + 1, mensagem_a_enviar, (estrutura->N+2)*sizeof(double));
	   	receberMensagem(myid + 1, myid,buff, (estrutura->N+2)*sizeof(double));
	   	dm2dSetLine(m,estrutura->n_linhas+1,buffer);
	  }
    if(myid<=estrutura->trab  && myid>1 && estrutura->trab>1){
      receberMensagem(myid-1, myid,buff2, (estrutura->N+2)*sizeof(double));
      dm2dSetLine(m,0,buffer2);
      mensagem_a_enviar2=dm2dGetLine(m,1);
    	enviarMensagem(myid, myid-1, mensagem_a_enviar2, (estrutura->N+2)*sizeof(double));
	  }

  }

  /* Vao ser enviadas as linhas de cada tarefa para a tarefa mestre */
  for (i = 1; i < estrutura->n_linhas + 1 ; i++){
    buffer2=dm2dGetLine(m,i);
    enviarMensagem(myid,0,buffer2,(estrutura->N+2)*sizeof(double));
  }
  dm2dFree(m);
  dm2dFree(aux);
      
  pthread_exit(NULL);
}

/*--------------------------------------------------------------------
| Function: parse_integer_or_exit
---------------------------------------------------------------------*/

int parse_integer_or_exit(char const *str, char const *name)
{
  int value;
 
  if(sscanf(str, "%d", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}

/*--------------------------------------------------------------------
| Function: parse_double_or_exit
---------------------------------------------------------------------*/

double parse_double_or_exit(char const *str, char const *name)
{
  double value;

  if(sscanf(str, "%lf", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}


/*--------------------------------------------------------------------
| Function: main
---------------------------------------------------------------------*/

int main (int argc, char** argv) {

  if(argc != 9) {
    fprintf(stderr, "\nNumero invalido de argumentos.\n");
    fprintf(stderr, "Uso: heatSim N tEsq tSup tDir tInf iteracoes trab csz\n\n");
    return 1;
  }

  /* argv[0] = program name */
  int N = parse_integer_or_exit(argv[1], "N");
  double tEsq = parse_double_or_exit(argv[2], "tEsq");
  double tSup = parse_double_or_exit(argv[3], "tSup");
  double tDir = parse_double_or_exit(argv[4], "tDir");
  double tInf = parse_double_or_exit(argv[5], "tInf");
  int iteracoes = parse_integer_or_exit(argv[6], "iteracoes");
  int trab = parse_integer_or_exit(argv[7], "trab");
  int csz = parse_integer_or_exit(argv[8], "csz");

  DoubleMatrix2D *matrix;


  fprintf(stderr, "\nArgumentos:\n"
	" N=%d tEsq=%.1f tSup=%.1f tDir=%.1f tInf=%.1f iteracoes=%d trab=%d csz=%d\n",
	N, tEsq, tSup, tDir, tInf, iteracoes, trab, csz);

  if(N < 1 || tEsq < 0 || tSup < 0 || tDir < 0 || tInf < 0 || iteracoes < 1 || trab < 1 || csz < 0 || N<trab || N%trab!=0) {
    fprintf(stderr, "\nErro: Argumentos invalidos.\n"
	" Lembrar que N >= 1, temperaturas >= 0 , iteracoes >= 1, trab >0 , csz >=0 , N>=trab e N divisivel por trab\n\n");
    return 1;
  }

  matrix = dm2dNew(N+2, N+2);


  if (matrix == NULL) {
    fprintf(stderr, "\nErro: Nao foi possivel alocar memoria para as matrizes.\n\n");
    return -1;
  }
  int i,j;
  args *slave_args;
  pthread_t *slaves;
  int t_iniciais[4];
  double teste3[N+2];
  double *teste4;
  teste4=teste3;

  slave_args=(args*)malloc(trab*sizeof(args));

  slaves=(pthread_t*)malloc(trab*sizeof(pthread_t));

  if (inicializarMPlib(csz,trab+1) == -1) {
    printf("Erro ao inicializar MPLib.\n"); return 1;
  }

  for(i=0; i<N+2; i++)
    dm2dSetLineTo(matrix, i, 0);

  dm2dSetLineTo (matrix, 0, tSup);
  dm2dSetLineTo (matrix, N+1, tInf);
  dm2dSetColumnTo (matrix, 0, tEsq);
  dm2dSetColumnTo (matrix, N+1, tDir);

  /*Informacao contendo temperaturas iniciais para ser enviada a cada tarefa trabalhadora presente no vetor t_iniciais*/

  t_iniciais[0]=tSup;
  t_iniciais[1]=tInf;
  t_iniciais[2]=tEsq;
  t_iniciais[3]=tDir;

  /* Vao ser iniciadas todas as estruturas e criadas as tarefas trabalhadoras */
  for (i = 0; i < trab ; i++){
  	slave_args[i].n_linhas=N/trab;
  	slave_args[i].N=N;
  	slave_args[i].id=i;
  	slave_args[i].iter=iteracoes;
  	slave_args[i].trab=trab;
  	if(pthread_create(&slaves[i], NULL, simul, &slave_args[i])){
      fprintf(stderr, "\nErro ao criar um escravo.\n");    
      return -1;
    }
  }

  /* Sao enviadas as informacoes iniciais */
  for(i=0; i < trab; i++){
    if(enviarMensagem(0,i+1,t_iniciais,sizeof(t_iniciais))==-1){
      fprintf(stderr, "\nErro ao enviar mensagem para um escravo.\n");    
      return -1;
    }
  }

  /* Vao ser recebidas as linhas de cada tarefa trabalhadora e colocadas na fatia certa na matriz original e vao ser terminadas as tarefas trabalhadoras */
  for(i=0;i<trab;i++){
    for(j = (slave_args[i].n_linhas * slave_args[i].id)+1; j <= (slave_args[i].n_linhas*(slave_args[i].id+1)); j++){
    if(receberMensagem(i+1, 0, teste3,(N+2)*sizeof(double))==-1){
      fprintf(stderr, "\nErro ao receber mensagem de um escravo.\n");    
      return -1;
    }
    dm2dSetLine(matrix,j,teste4);
    }
    if (pthread_join(slaves[i], NULL)) {
      fprintf(stderr, "\nErro ao esperar por um escravo.\n");    
      return -1;
    }
  }

  free(slaves);
  free(slave_args);

  dm2dPrint(matrix);
  dm2dFree(matrix);
  libertarMPlib();

  return 0;
}
