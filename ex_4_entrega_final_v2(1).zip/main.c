/*
// Projeto SO - exercicio 4
// Sistemas Operativos, DEI/IST/ULisboa 2017-18
//-----------------------Grupo 66-------------------------------------
//----------------Ricardo Velhinho 86505------------------------------
//----------------Manuel Valverde  86468------------------------------
*/

/*--------------------------------------------------------------------
| Includes
---------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#include "matrix2d.h"
#include "mplib3.h"

/*--------------------------------------------------------------------
| Defines
---------------------------------------------------------------------*/

typedef struct{
  	int n_linhas;
  	int N;
  	int iter;
  	int trab;
    int id;
    int periodoS;
    char *fichS;
    double maxD;
    double *ptr;
    DoubleMatrix2D *matrix;
    DoubleMatrix2D *matrix_aux;
} args;

pthread_mutex_t mutex;
pthread_cond_t cond;
pid_t pid;
int count=0;
int count_trab=0;
int count_iter=0;
double d=100;
int status=0;
char *fichS_g,*fichS_g_backup;
int N_g;
int periodoS_g;
DoubleMatrix2D *matrix_g;

/*--------------------------------------------------------------------
| Function: saveMatrix
| Description: Vai armazenar a matriz atual num ficheiro com o nome de fichS
---------------------------------------------------------------------*/

void saveMatrix(){
      FILE *f;
      pid=getpid();
      /* Verifica se ainda existe um processo filho ativo e caso exista vai esperar */
      if(waitpid(-1,&status,WNOHANG) == 0) 
        wait(&status);
      /* Cria um novo processo filho que vai armazenar a matriz */
      pid=fork();
      if ( pid==0 ){
        f=fopen(fichS_g_backup,"w");
        if(f!=NULL){
          for (int i = 0; i <= N_g + 1; i++){
            for (int j = 0; j <= N_g + 1; j++) 
              fprintf(f," %.4f",dm2dGetEntry(matrix_g, i, j));
            fprintf(f,"\n");
          }
        fclose(f);
        /* Apos armazenar a matriz num ficheiro substituto, vai passar para o ficheiro principal */
        rename(fichS_g_backup,fichS_g);
        }
        exit(0);
      }
}

/*--------------------------------------------------------------------
| Functions: INThandler & ALRMhandler
| Description: rotinas de tratamento
---------------------------------------------------------------------*/

void INThandler(int sig){
    saveMatrix();
    printf("\n");
    exit(0);
}

void ALRMhandler(int sig){
    if(signal(SIGALRM, ALRMhandler) == SIG_ERR)
      printf("Problema ao apanhar SIGALRM");
    saveMatrix();
    alarm(periodoS_g);
}

/*--------------------------------------------------------------------
| Functions: wait_for_all & wait_for_all2
| Description: Esperam que todas as tarefas acabem uma iteracao para que possam prosseguir
---------------------------------------------------------------------*/

void wait_for_all(args *estrutura){
  args *e = (args *) estrutura;
  double local_max=0.0;
  pthread_mutex_lock(&mutex);

  /* Vai ser incrementada a variavel que conta o numero de threads que ja chegaram a esta funcao */
  count+=1;

  if(count==e->trab){
    count=0;
    for (int j=0;j<e->trab;j++){
      if(e->ptr[j]>local_max)
        local_max=e->ptr[j];
    }
    d=local_max;
    count_iter++;
    /* Vai atualizar a matriz global a cada iteracao feita */
    matrix_g=e->matrix;
    pthread_cond_broadcast(&cond);
  }
  /* Caso ainda faltem chegar mais threads, a thread vai esperar */
  else{
    pthread_cond_wait(&cond,&mutex);
  }
  pthread_mutex_unlock(&mutex);
}

/* A wait_for_all2 corresponde a primeira iteracao */

void wait_for_all2(args *estrutura){
  args *e = (args *) estrutura;
  pthread_mutex_lock(&mutex);

  /* Vai ser incrementada a variavel que conta o numero de threads que ja chegaram a esta funcao */
  count+=1;

  if(count==e->trab){
    count=0;
    pthread_cond_broadcast(&cond);
  }
  /* Caso ainda faltem chegar mais threads, a thread vai esperar */
  else{
    pthread_cond_wait(&cond,&mutex);
  }
  pthread_mutex_unlock(&mutex);
}

/*--------------------------------------------------------------------
| Function: simul
| Description: Calcula cada fatia de cada tarefa e envia para a thread 0
---------------------------------------------------------------------*/

void *simul(void *a) {
	args *estrutura = (args *) a;
  int iter=0, i, j;
  double soma, value, d_aux=0.0;

	DoubleMatrix2D *m,*aux, *tmp;

	if(estrutura->N+2<2 || estrutura->n_linhas+2<2)
	 return NULL;

  pthread_mutex_lock(&mutex);
  m=estrutura->matrix;
  aux=estrutura->matrix_aux;
  pthread_mutex_unlock(&mutex);


  do {
    pthread_mutex_lock(&mutex);
    d_aux=0.0;
    for (i = (estrutura->n_linhas*estrutura->id)+1; i <= estrutura->n_linhas*(estrutura->id+ 1); i++)
      for (j = 1; j < estrutura->N + 1; j++) {
        value = ( dm2dGetEntry(m, i-1, j) + dm2dGetEntry(m, i+1, j) +
		    dm2dGetEntry(m, i, j-1) + dm2dGetEntry(m, i, j+1) ) / 4.0;
        if(iter>0){
          soma=value - dm2dGetEntry(m, i, j);
          dm2dSetEntry(aux, i, j, value);
          if (soma>d_aux){
            estrutura->ptr[estrutura->id]=soma;
            d_aux=soma;
          }

        }
        else{
          dm2dSetEntry(aux, i, j, value);
        }
        

      }
    tmp = aux;
    aux = m;
    m = tmp;
    pthread_mutex_unlock(&mutex);

    if(iter>0)
    wait_for_all(estrutura);

    else  wait_for_all2(estrutura);

  } while (++iter<estrutura->iter && d>=estrutura->maxD);
  pthread_exit(NULL);
}

/*--------------------------------------------------------------------
| Function: parse_integer_or_exit
---------------------------------------------------------------------*/

int parse_integer_or_exit(char const *str, char const *name)
{
  int value;
 
  if(sscanf(str, "%d", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}

/*--------------------------------------------------------------------
| Function: parse_double_or_exit
---------------------------------------------------------------------*/

double parse_double_or_exit(char const *str, char const *name)
{
  double value;

  if(sscanf(str, "%lf", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}


/*--------------------------------------------------------------------
| Function: main
---------------------------------------------------------------------*/

int main (int argc, char** argv) {

  if(argc != 11) {
    fprintf(stderr, "\nNumero invalido de argumentos.\n");
    fprintf(stderr, "Uso: heatSim N tEsq tSup tDir tInf iteracoes trab maxD\n\n");
    return 1;
  }

  /* argv[0] = program name */
  int N = parse_integer_or_exit(argv[1], "N");
  double tEsq = parse_double_or_exit(argv[2], "tEsq");
  double tSup = parse_double_or_exit(argv[3], "tSup");
  double tDir = parse_double_or_exit(argv[4], "tDir");
  double tInf = parse_double_or_exit(argv[5], "tInf");
  int iteracoes = parse_integer_or_exit(argv[6], "iteracoes");
  int trab = parse_integer_or_exit(argv[7], "trab");
  double maxD = parse_double_or_exit(argv[8], "maxD");
  char *fichS= argv[9];
  int periodoS = parse_integer_or_exit(argv[10], "periodoS");


  DoubleMatrix2D *matrix;
  DoubleMatrix2D *matrix_aux;


  fprintf(stderr, "\nArgumentos:\n"
	" N=%d tEsq=%.1f tSup=%.1f tDir=%.1f tInf=%.1f iteracoes=%d trab=%d maxD=%f periodoS=%d\n",
	N, tEsq, tSup, tDir, tInf, iteracoes, trab, maxD,periodoS);

  if(N < 1 || tEsq < 0 || tSup < 0 || tDir < 0 || tInf < 0 || iteracoes < 1 || trab < 1 || maxD < 0 || N<trab || N%trab!=0 || periodoS<0) {
    fprintf(stderr, "\nErro: Argumentos invalidos.\n"
	" Lembrar que N >= 1, temperaturas >= 0 , iteracoes >= 1, trab >0 , maxD >=0 , N>=trab, N divisivel por trab e periodo>=0 \n\n");
    return 1;
  }

  matrix = dm2dNew(N+2, N+2);
  matrix_aux = dm2dNew(N+2, N+2);
  matrix_g = dm2dNew(N+2, N+2);

  if (matrix == NULL || matrix_aux == NULL) {
    fprintf(stderr, "\nErro: Nao foi possivel alocar memoria para as matrizes.\n\n");
    return -1;
  }



  int i;
  double *ptr;
  args *slave_args;
  pthread_t *slaves;
  FILE *f;
  N_g=N;
  fichS_g=fichS;
  periodoS_g=periodoS;
  fichS_g_backup=(char*)malloc((strlen(fichS)+5)*sizeof(char));
  strcpy(fichS_g_backup,fichS);
  fichS_g_backup=strcat(fichS_g_backup,"~");

  ptr=(double*)malloc(trab*sizeof(double));
  for (int j=0;j<trab;j++){
    ptr[j]=0.0;
  }

  if(signal(SIGINT, INThandler) ==  SIG_ERR)
    printf("Problema ao apanhar SIGINT");

  if(signal(SIGALRM, ALRMhandler) == SIG_ERR)
    printf("Problema ao apanhar SIGALRM");
  if (periodoS != 0) alarm(periodoS);


  slave_args=(args*)malloc(trab*sizeof(args));

  slaves=(pthread_t*)malloc(trab*sizeof(pthread_t));

  count_trab=trab;

  pthread_mutex_init(&mutex,NULL);
  pthread_cond_init(&cond,NULL);

  for(i=0; i<N+2; i++)
    dm2dSetLineTo(matrix, i, 0);

  dm2dSetLineTo (matrix, 0, tSup);
  dm2dSetLineTo (matrix, N+1, tInf);
  dm2dSetColumnTo (matrix, 0, tEsq);
  dm2dSetColumnTo (matrix, N+1, tDir);

  dm2dCopy (matrix_aux, matrix);
  matrix_g=matrix;

  /* Verifica se existe algum ficheiro que contenha uma Matriz a ser utilizada */

  f=fopen(fichS,"r+");
  if(f!=NULL){
    matrix=readMatrix2dFromFile(f,N+2,N+2);
    dm2dCopy (matrix_aux, matrix);
    fclose(f);
  }

  /* Vao ser iniciadas todas as estruturas e criadas as tarefas trabalhadoras */

  for (i = 0; i < trab ; i++){
  	slave_args[i].n_linhas=N/trab;
  	slave_args[i].N=N;
  	slave_args[i].matrix=matrix;
    slave_args[i].matrix_aux=matrix_aux;
  	slave_args[i].iter=iteracoes;
  	slave_args[i].trab=trab;
    slave_args[i].id=i;
    slave_args[i].maxD=maxD;
    slave_args[i].ptr=ptr;
    slave_args[i].fichS=fichS;
    slave_args[i].periodoS=periodoS;
  	if(pthread_create(&slaves[i], NULL, simul, &slave_args[i])){
      fprintf(stderr, "\nErro ao criar um escravo.\n");    
      return -1;
    }
  }

  /* Vao ser recebidas as linhas de cada tarefa trabalhadora e colocadas na fatia certa na matriz original e vao ser terminadas as tarefas trabalhadoras */
  for(i=0;i<trab;i++){
    if (pthread_join(slaves[i], NULL)) {
      fprintf(stderr, "\nErro ao esperar por um escravo.\n");    
      return -1;
    }
  }

  if((count_iter%2==0) | (count_iter==1)) dm2dPrint(matrix_aux);
  else dm2dPrint(matrix);
  dm2dFree(matrix);
  free(slaves);
  free(slave_args);
  dm2dFree(matrix_aux);
  /* Verifica se ainda existe algum processo filho ativo e apaga o ficheiro com a salvaguarda */
  if(waitpid(-1,&status,WNOHANG) == 0) 
        wait(&status);
  unlink(fichS);
  return 0;
}
