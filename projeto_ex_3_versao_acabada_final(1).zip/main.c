/*
// Projeto SO - exercicio 3, version 03
// Sistemas Operativos, DEI/IST/ULisboa 2017-18
//-----------------------Grupo 66-------------------------------------
//----------------Ricardo Velhinho 86505------------------------------
//----------------Manuel Valverde  86468------------------------------
*/

/*--------------------------------------------------------------------
| Includes
---------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#include "matrix2d.h"
#include "mplib3.h"

/*--------------------------------------------------------------------
| Defines
---------------------------------------------------------------------*/

typedef struct{
  	int n_linhas;
  	int N;
  	int iter;
  	int trab;
    int id;
    double maxD;
    DoubleMatrix2D *matrix;
    DoubleMatrix2D *matrix_aux;
} args;

pthread_mutex_t mutex;
pthread_cond_t cond;
int count=0;
int count_trab=0;
int count_iter=0;
double d=0.0;



/*--------------------------------------------------------------------
| Function: simul
| Description: Calcula cada fatia de cada tarefa e envia para a thread 0
---------------------------------------------------------------------*/

void wait_for_all(args *estrutura){
  args *e = (args *) estrutura;
  pthread_mutex_lock(&mutex);

  /* Vai ser incrementada a variavel que conta o numero de threads que ja chegaram a esta funcao */
  count+=1;
  /* Caso todas as threads ja tenham chegado vaose libertar e continuar para a proxima iteracao */
  if(count==e->trab){
    count=0;
    pthread_cond_broadcast(&cond);
  }
  /* Caso ainda faltem chegar mais threads, a thread vai esperar */
  else{
    pthread_cond_wait(&cond,&mutex);
  }
  pthread_mutex_unlock(&mutex);
}

void *simul(void *a) {
	args *estrutura = (args *) a;
  int iter, i, j;
  double soma, value;

	DoubleMatrix2D *m,*aux, *tmp;

	if(estrutura->N+2<2 || estrutura->n_linhas+2<2)
	 return NULL;

  pthread_mutex_lock(&mutex);
  m=estrutura->matrix;
  aux=estrutura->matrix_aux;
  pthread_mutex_unlock(&mutex);


  for (iter = 0; iter < estrutura->iter; iter++) {
    pthread_mutex_lock(&mutex);
    d=0;
    for (i = (estrutura->n_linhas*estrutura->id)+1; i <= estrutura->n_linhas*(estrutura->id+ 1); i++)
      for (j = 1; j < estrutura->N + 1; j++) {
        value = ( dm2dGetEntry(m, i-1, j) + dm2dGetEntry(m, i+1, j) +
		    dm2dGetEntry(m, i, j-1) + dm2dGetEntry(m, i, j+1) ) / 4.0;
        if(iter>0){
          /* Vai ser calculada a diferenca entre todos os valores anteriores e atuais sendo d a variavel que contem a maior diferenca */
          soma=value - dm2dGetEntry(m, i, j);
          dm2dSetEntry(aux, i, j, value);
          if (soma>d){
            d=soma;
          }

        }
        else{
          dm2dSetEntry(aux, i, j, value);
        }
        

      }
    tmp = aux;
    aux = m;
    m = tmp;
    pthread_mutex_unlock(&mutex);

    wait_for_all(estrutura);

    pthread_mutex_lock(&mutex);

    /* Verificase se a diferenca e menor que o maxD e caso seja vaise terminar a thread */
    if(iter>0 && d<estrutura->maxD){
      count_iter=iter;
      count_trab-=1;
      pthread_cond_broadcast(&cond);
      pthread_mutex_unlock(&mutex);
      pthread_exit(NULL);
    }
    else{
      pthread_mutex_unlock(&mutex);
    }

    /* Vai esperar por todas as threads antes de continuar para a proxima iteracao */

    wait_for_all(estrutura);

    if(estrutura->trab!=count_trab){
      pthread_exit(NULL);
    }


    

  
  }
  count_iter=iter;
  pthread_exit(NULL);
}

/*--------------------------------------------------------------------
| Function: parse_integer_or_exit
---------------------------------------------------------------------*/

int parse_integer_or_exit(char const *str, char const *name)
{
  int value;
 
  if(sscanf(str, "%d", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}

/*--------------------------------------------------------------------
| Function: parse_double_or_exit
---------------------------------------------------------------------*/

double parse_double_or_exit(char const *str, char const *name)
{
  double value;

  if(sscanf(str, "%lf", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}


/*--------------------------------------------------------------------
| Function: main
---------------------------------------------------------------------*/

int main (int argc, char** argv) {

  if(argc != 9) {
    fprintf(stderr, "\nNumero invalido de argumentos.\n");
    fprintf(stderr, "Uso: heatSim N tEsq tSup tDir tInf iteracoes trab maxD\n\n");
    return 1;
  }

  /* argv[0] = program name */
  int N = parse_integer_or_exit(argv[1], "N");
  double tEsq = parse_double_or_exit(argv[2], "tEsq");
  double tSup = parse_double_or_exit(argv[3], "tSup");
  double tDir = parse_double_or_exit(argv[4], "tDir");
  double tInf = parse_double_or_exit(argv[5], "tInf");
  int iteracoes = parse_integer_or_exit(argv[6], "iteracoes");
  int trab = parse_integer_or_exit(argv[7], "trab");
  double maxD = parse_double_or_exit(argv[8], "maxD");

  DoubleMatrix2D *matrix;
  DoubleMatrix2D *matrix_aux;


  fprintf(stderr, "\nArgumentos:\n"
	" N=%d tEsq=%.1f tSup=%.1f tDir=%.1f tInf=%.1f iteracoes=%d trab=%d maxD=%f\n",
	N, tEsq, tSup, tDir, tInf, iteracoes, trab, maxD);

  if(N < 1 || tEsq < 0 || tSup < 0 || tDir < 0 || tInf < 0 || iteracoes < 1 || trab < 1 || maxD < 0 || N<trab || N%trab!=0) {
    fprintf(stderr, "\nErro: Argumentos invalidos.\n"
	" Lembrar que N >= 1, temperaturas >= 0 , iteracoes >= 1, trab >0 , maxD >=0 , N>=trab e N divisivel por trab\n\n");
    return 1;
  }

  matrix = dm2dNew(N+2, N+2);
  matrix_aux = dm2dNew(N+2, N+2);

  if (matrix == NULL || matrix_aux == NULL) {
    fprintf(stderr, "\nErro: Nao foi possivel alocar memoria para as matrizes.\n\n");
    return -1;
  }


  int i;
  args *slave_args;
  pthread_t *slaves;

  slave_args=(args*)malloc(trab*sizeof(args));

  slaves=(pthread_t*)malloc(trab*sizeof(pthread_t));

  count_trab=trab;

  pthread_mutex_init(&mutex,NULL);
  pthread_cond_init(&cond,NULL);

  for(i=0; i<N+2; i++)
    dm2dSetLineTo(matrix, i, 0);

  dm2dSetLineTo (matrix, 0, tSup);
  dm2dSetLineTo (matrix, N+1, tInf);
  dm2dSetColumnTo (matrix, 0, tEsq);
  dm2dSetColumnTo (matrix, N+1, tDir);

  dm2dCopy (matrix_aux, matrix);

  /* Vao ser iniciadas todas as estruturas e criadas as tarefas trabalhadoras */
  for (i = 0; i < trab ; i++){
  	slave_args[i].n_linhas=N/trab;
  	slave_args[i].N=N;
  	slave_args[i].matrix=matrix;
    slave_args[i].matrix_aux=matrix_aux;
  	slave_args[i].iter=iteracoes;
  	slave_args[i].trab=trab;
    slave_args[i].id=i;
    slave_args[i].maxD=maxD;
  	if(pthread_create(&slaves[i], NULL, simul, &slave_args[i])){
      fprintf(stderr, "\nErro ao criar um escravo.\n");    
      return -1;
    }
  }

  /* Vao ser recebidas as linhas de cada tarefa trabalhadora e colocadas na fatia certa na matriz original e vao ser terminadas as tarefas trabalhadoras */
  for(i=0;i<trab;i++){
    if (pthread_join(slaves[i], NULL)) {
      fprintf(stderr, "\nErro ao esperar por um escravo.\n");    
      return -1;
    }
  }
  if(count_iter%2!=0|| iteracoes==1 ) dm2dPrint(matrix_aux);
  else dm2dPrint(matrix);
  dm2dFree(matrix);
  free(slaves);
  free(slave_args);
  dm2dFree(matrix_aux);

  return 0;
}
